package com.hongoctuan.admin.ungdungxemphim.DTO;

/**
 * Created by admin on 5/26/2016.
 */
public class LichChieuDTO {
    public String getTenphim() {
        return tenphim;
    }

    public void setTenphim(String tenphim) {
        this.tenphim = tenphim;
    }

    public String getThoigianchieu() {
        return thoigianchieu;
    }

    public void setThoigianchieu(String thoigianchieu) {
        this.thoigianchieu = thoigianchieu;
    }

    public String getKythuat() {
        return kythuat;
    }

    public void setKythuat(String kythuat) {
        this.kythuat = kythuat;
    }

    public String getMalichchieu() {
        return malichchieu;
    }

    public void setMalichchieu(String malichchieu) {
        this.malichchieu = malichchieu;
    }

    public String getTenrap() {
        return tenrap;
    }

    public void setTenrap(String tenrap) {
        this.tenrap = tenrap;
    }

    public String getGiave() {
        return giave;
    }

    public void setGiave(String giave) {
        this.giave = giave;
    }

    public String getPhongchieu() {
        return phongchieu;
    }

    public void setPhongchieu(String phongchieu) {
        this.phongchieu = phongchieu;
    }

    public String tenphim;
    public String thoigianchieu;
    public String kythuat;
    public String malichchieu;
    public String tenrap;
    public String giave;
    public String phongchieu;
//    int id;
//    String MaPhim;
//    String ThoiGianChieu;
//    int MaRap;
//
//    public int getMaPhong() {
//        return MaPhong;
//    }
//
//    public void setMaPhong(int maPhong) {
//        MaPhong = maPhong;
//    }
//
//    public int getMaRap() {
//        return MaRap;
//    }
//
//    public void setMaRap(int maRap) {
//        MaRap = maRap;
//    }
//
//    public String getThoiGianChieu() {
//        return ThoiGianChieu;
//    }
//
//    public void setThoiGianChieu(String thoiGianChieu) {
//        ThoiGianChieu = thoiGianChieu;
//    }
//
//    public String getMaPhim() {
//        return MaPhim;
//    }
//
//    public void setMaPhim(String maPhim) {
//        MaPhim = maPhim;
//    }
//
//    public int getId() {
//        return id;
//    }
//
//    public void setId(int id) {
//        this.id = id;
//    }
//
//    int MaPhong;
}
