package com.hongoctuan.admin.ungdungxemphim.DTO;

/**
 * Created by admin on 6/9/2016.
 */
public class GioiThieuDTO {
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNoidung() {
        return noidung;
    }

    public void setNoidung(String noidung) {
        this.noidung = noidung;
    }

    public String getHinhanh() {
        return hinhanh;
    }

    public void setHinhanh(String hinhanh) {
        this.hinhanh = hinhanh;
    }

    String id;
    String noidung;
    String hinhanh;
}
