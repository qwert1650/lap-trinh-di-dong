package com.hongoctuan.admin.ungdungxemphim.DTO;

/**
 * Created by admin on 6/10/2016.
 */
public class SumRatingDTO {
    public int getTongso() {
        return tongso;
    }

    public void setTongso(int tongso) {
        this.tongso = tongso;
    }

    public float getTongdiem() {
        return tongdiem;
    }

    public void setTongdiem(float tongdiem) {
        this.tongdiem = tongdiem;
    }

    int tongso;
    float tongdiem;

}
