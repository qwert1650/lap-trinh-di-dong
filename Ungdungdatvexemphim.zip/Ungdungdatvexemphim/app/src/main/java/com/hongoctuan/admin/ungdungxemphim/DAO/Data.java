package com.hongoctuan.admin.ungdungxemphim.DAO;

/**
 * Created by admin on 5/10/2016.
 */
public class Data {
    public String createDataComment1() {
        String sql = "INSERT INTO \"binhluan\" VALUES(1,'hd01','User A','phim rất hay!!!');";
        return sql;
    }
    public String createDataComment2() {
        String sql = "INSERT INTO \"binhluan\" VALUES(2,'hd02','User B','Hay quá!');";
        return sql;
    }
    public String createDataComment3() {
        String sql = "INSERT INTO \"binhluan\" VALUES(3,'hd02','User A','phim gây cứng!!!');";
        return sql;
    }
    public String createDataComment4() {
        String sql = "INSERT INTO \"binhluan\" VALUES(4,'hd02','User C','Phim mới ah!');";
        return sql;
    }
    public String createDataComment5() {
        String sql = "INSERT INTO \"binhluan\" VALUES(5,'hd02','User D','Nội dung bình thường!!!');";
        return sql;
    }public String createDataComment6() {
        String sql = "INSERT INTO \"binhluan\" VALUES(6,'hd03','Nguyen Văn Tám','coi hoài không chán');";
        return sql;
    }public String createDataComment7() {
        String sql = "INSERT INTO \"binhluan\" VALUES(7,'hd04','Trân Văn Năm','coi không chớp mắt!!!');\n";
        return sql;
    }public String createDataComment8() {
        String sql = "INSERT INTO \"binhluan\" VALUES(8,'hd04','Tám tường tận','phim chán ngắt.');";
        return sql;
    }public String createDataComment9() {
        String sql = "INSERT INTO \"binhluan\" VALUES(9,'hd05','Trần Văn Mỹ','để xem thử!!!');";
        return sql;
    }public String createDataComment10() {
        String sql = "INSERT INTO \"binhluan\" VALUES(10,'hh01','nguyễn văn b','Phim hay quá!!!');";
        return sql;
    }public String createDataComment11() {
        String sql = "INSERT INTO \"binhluan\" VALUES(11,'hh01','nguyễn văn c','Phim hay quá!!!');";
        return sql;
    }public String createDataComment12() {
        String sql = "INSERT INTO \"binhluan\" VALUES(12,'hh02','Nguyen Văn Tùng','coi hoài không chán');";
        return sql;
    }public String createDataComment13() {
        String sql = "INSERT INTO \"binhluan\" VALUES(13,'hh03','Hồ Văn Thiện','Hay');";
        return sql;
    }public String createDataComment14() {
        String sql = "INSERT INTO \"binhluan\" VALUES(14,'hh03','Thanh Tâm','Hay wa');";
        return sql;
    }public String createDataComment15() {
        String sql = "INSERT INTO \"binhluan\" VALUES(15,'hh03','Thanh Tuấn','Tuyệt vời');";
        return sql;
    }public String createDataComment16() {
        String sql = "INSERT INTO \"binhluan\" VALUES(16,'hh04','Thanh Tuấn','Hết chỗ chê');";
        return sql;
    }public String createDataComment17() {
        String sql = "INSERT INTO \"binhluan\" VALUES(17,'hh05','Lê','Bình thường');";
        return sql;
    }public String createDataComment18() {
        String sql = "INSERT INTO \"binhluan\" VALUES(18,'hh05','Mít','Phim không hay');";
        return sql;
    }public String createDataComment19() {
        String sql = "INSERT INTO \"binhluan\" VALUES(19,'gt01','Văn Cam','Phim không hay');";
        return sql;
    }public String createDataComment20() {
        String sql = "INSERT INTO \"binhluan\" VALUES(20,'gt01','Văn Quýt','Phim hay');";
        return sql;
    }public String createDataComment21() {
        String sql = "INSERT INTO \"binhluan\" VALUES(21,'gt02','nguyễn văn b','Phim hay quá!!!');";
        return sql;
    }public String createDataComment22() {
        String sql = "INSERT INTO \"binhluan\" VALUES(22,'gt02','Thanh Tuấn','Tuyệt vời');";
        return sql;
    }public String createDataComment23() {
        String sql = "INSERT INTO \"binhluan\" VALUES(23,'gt02','nguyễn văn b','Phim hay quá!!!');";
        return sql;
    }public String createDataComment24() {
        String sql = "INSERT INTO \"binhluan\" VALUES(24,'gt03','Hồ Văn Thiện','Hay');";
        return sql;
    }public String createDataComment25() {
        String sql = "INSERT INTO \"binhluan\" VALUES(25,'gt03','User D','Nội dung bình thường!!!');";
        return sql;
    }public String createDataComment26() {
        String sql = "INSERT INTO \"binhluan\" VALUES(26,'gt05','Nguyen Văn Tùng','coi hoài không chán');";
        return sql;
    }


    public String createDataMovie1(){
        String sql = "INSERT INTO \"phim\" VALUES('hd01','Biệt đội đánh thuê','Sylvester Stallone','Lý Liên Kiệt, Sylvester Stallone, Jason Statham, Jet Li, Dolph Lundgren','4','Bộ phim là cuộc chiến của một nhóm lính đánh thuê, nhằm vào Nam Mỹ để hoàn thành nhiệm vụ là lật đổ một nhà độc tài tại đây. Nhà độc tài là tướng quân Garza. Dù là tướng quân nhưng ông lại bị một cưu điệp viên CIA  thao túng và ép phải ủng hộ cho việc sản xuất thuốc phiện.Khi nhóm đánh thuê do Barney Ross chỉ huy được chính CIA nhờ tiêu diệt cựu điệp viên xấu Paine thì Ross đã biết nhiệm vụ lần này vô cùng nguy hiểm. Anh đã có thể dừng lại nhưng sự ám ảnh về cô gái có bức vẽ tuyệt vời Sandra đã đẩy anh và nhóm đến một cuộc chiến đầy cam go.','hd','0qjxbz7cBmU');";
        return sql;
    }
    public String createDataMovie2(){
        String sql = "INSERT INTO \"phim\" VALUES('hd02','Biệt đội đánh thuê 2','Simon West','Sylvester Stallone, Liam Hemsworth và Randy Couture','4','Sai lầm trong một lần làm nhiệm vụ dẫn đến cái chết của một thành viên trong biệt đội đánh thuê. Nhóm đón nhận thêm hai thành viên mới, và trở lại nơi kẻ thù để ngăn chặn một vũ khí hủy diệt hàng loạt.','hd','WF8Drc9qbaI');";
        return sql;
    }
    public String createDataMovie3(){
        String sql = "INSERT INTO \"phim\" VALUES('hd03','Fast And Furious 6','Justin Lin ','Vin Diesel, Paul Walker, Dwayne Johnson','4','Đặc vụ Hobbs phải nhờ đến Dom và nhóm của anh giúp sức trong cuộc vây bắt 1 băng đảng do Owen Shaw cầm đầu. Đổi lại, Dom muốn một bản lý lịch \"sạch sẽ\" cho mọi người trong đội...','hd','dKi5XoeTN0k');";
        return sql;
    }
    public String createDataMovie4(){
        String sql = "INSERT INTO \"phim\" VALUES('hd04','Fast & Furious 7','James Wan','Vin Diesel, Dwayne Johnson, Jason Statham, Paul Walker','4','Quá Nhanh Quá Nguy Hiểm 7 - Fast & Furious 7 : là phần 7 của loạt series Fast & Furious nổi tiếng. Ở cuối phần trước, tưởng chừng như mọi chuyện đã kết thúc, và mở ra một cuộc sống bình lặng, khi cả nhóm đã tiêu diệt được Owen Shaw. Thì trong phần này, sự xuất hiện của Deckard Shaw, người đã giết chết Han, và khiêu chiến với Dominic Toretto, để trả thù cho em trai Owen Shaw của mình, đã làm thay đổi tất cả. Khiến cho cuộc đụng độ giữa 2 băng nhóm lên đến đỉnh điểm...','hd','Skpu5HaVkOc');";
        return sql;
    }
    public String createDataMovie5(){
        String sql = "INSERT INTO \"phim\" VALUES('hd05','Fast & Furious 8','F. Gary Gray','Gary Scott Thompson','5','Tập 8 này do F. Gary Gray làm đạo diễn dự kiến ra rạp vào ngày 17/4/2017 với sự tham gia của dàn diễn viên cũ Vin Diesel, Dwayne Johnson, Tyrese, Ludacris, Michelle Rodriguez…','hd','zU2GRKB1ysU');";
        return sql;
    }
    public String createDataMovie6(){
        String sql = "INSERT INTO \"phim\" VALUES('hh01','Frozen (2013)','Chris Buck, Jennifer Lee','Idina Menzel, Josh Gad, Kristen Bell','4','Là một bộ phim hoạt hình hài 3D của Walt Disney. Khi vương quốc cìm vào trong băng giá mãi mãi, Anna (Kristen Bell) không hề sợ hãi gia nhập lực lượng với nhà leo núi Kristoff (Jonathan Groff) và đám tuần lộc để tìm kiếm em gái của cô là Snow Queen Elsa (Idina Menzel) để hóa giải lời nguyền','hh','TbQm5doF_Uc');";
        return sql;
    }
    public String createDataMovie7(){
        String sql = "INSERT INTO \"phim\" VALUES('hh02','Jungle Book','Jon Favreau','Scarlett Johansson, Ben Kingsley, Idris Elba...','5','Phim The Jungle Book (2016) nói về chuyến phiêu lưu của Mowgli – một cậu bé mồ côi được đàn chó sói nuôi dưỡng trong rừng già Ấn Độ. Ngày qua ngày, Mowgli cảm thấy mình không còn được chào đón ở mái nhà tự nhiên này nữa, bởi một con hổ hung dữ tên Shere Khan tuyên bố sẽ tiêu diệt những sinh vật có khả năng gây nên hiểm họa, sau khi hắn bị loài người tấn công.','hh','RLS46DjhG_k');";
        return sql;
    }
    public String createDataMovie8(){
        String sql = "INSERT INTO \"phim\" VALUES('hh03','KungFu Panda','Jennifer Yuh ','Jack Black, Angelina Jolie, Dustin Hoffman, Gary Oldman, Jackie Chan, Seth Rogen, Lucy Liu, David Cross, James Hong, Michelle Yeoh, Danny McBride, Dennis Haysbert, Jean-Claude Van Damme, Victor Garber, Mike Bell','3','Trong Kung Fu Panda , cuộc sống mới của anh chàng gấu trúc Po nay đã là Thần Long Đại Hiệp là phải bảo vệ thung lũng Hòa Bình cùng với bạn bè cùng nhóm Ngũ đại hào kiệt gồm Đại sư tỷ Tigress, Sư huynh Crane, Sư huynh Mantis, Sư tỷ Viper và Sư huynh Monkey. Nhưng cuộc sống mới tuyệt vời của Po bị đe dọa bởi sự xuất hiện của một nhân vật phản diện ghê gớm, kẻ có kế hoạch sử dụng vũ khí bí mật vô cùng lợi hại để thôn tính Trung Quốc và phá hủy kung fu. Po và nhóm Ngũ đại hào kiệt','hh','PXi3Mv6KMzY');";
        return sql;
    }
    public String createDataMovie9(){
        String sql = "INSERT INTO \"phim\" VALUES('hh04','KungFu Panda 2','Jennifer Yuh ','Jack Black, Angelina Jolie, Dustin Hoffman, Gary Oldman, Jackie Chan, Seth Rogen, Lucy Liu, David Cross, James Hong, Michelle Yeoh, Danny McBride, Dennis Haysbert, Jean-Claude Van Jack Black, Angelina Jolie','4','Trong Kung Fu Panda 2, cuộc sống mới của anh chàng gấu trúc Po nay đã là Thần Long Đại Hiệp là phải bảo vệ thung lũng Hòa Bình cùng với bạn bè cùng nhóm Ngũ đại hào kiệt gồm Đại sư tỷ Tigress, Sư huynh Crane, Sư huynh Mantis, Sư tỷ Viper và Sư huynh Monkey','hh','YIW5oo-8NYw');";
        return sql;
    }
    public String createDataMovie10(){
        String sql = "INSERT INTO \"phim\" VALUES('hh05','KungFu Panda 3','Alessandro Carloni,Jennifer Yuh','Jack Black, Angelina Jolie, Dustin Hoffman','5','Năm 2016 tới đây, một trong những series phim hoạt hình ăn khách nhất thế giới sẽ trở lại màn ảnh – KUNG FU PANDA 3. Xuất hiện lần đầu vào năm 2008, KUNG FU PANDA đã nhanh chóng trở thành hiện tượng phòng vé toàn cầu với cuộc phiêu lưu hài hước và những màn võ thuật điêu luyện của Gấu Trúc Po.Khán giả yêu thích bộ phim sẽ không còn phải chờ lâu để được gặp gỡ Po và những người bạn của cậu nữa','hh','10r9ozshGVE');";
        return sql;
    }
    public String createDataMovie11(){
        String sql = "INSERT INTO \"phim\" VALUES('gt01','Transformers 1','Michael Bay','Shia LaBeouf, Megan Fox, Josh Duhamel','4','Trong một tương lai gần, Trái đất tình cờ bị cuốn vào một cuộc chiến liên hành tinh giữa hai chủng tộc Người máy với những vũ khí hủy diệt khủng khiếp mà một trong hai chủng tộc đó có khả năng biến hình đa dạng','gt','gAjgXlvVexI');";
        return sql;
    }
    public String createDataMovie12(){
        String sql = "INSERT INTO \"phim\" VALUES('gt02','Transformers 2','Michael Bay','Shia LaBeouf, Megan Fox, Josh Duhamel','4',' Quân Deceptico đã trở lại Trái Đất với mục tiêu đuổi bắt Sam Witwicky, sau khi người anh hùng trẻ tuổi này vô tình biết được bí mật về Người Máy Biến Hình và lịch sử cổ xưa của họ. Với sứ mệnh bảo vệ loài người, thủ lĩnh Optimus Prime lập nên liên minh quân đội quốc tế để sẵn sàng cho cuộc chiến oanh liệt lần thứ 2.','gt','uH3STHC63hU');";
        return sql;
    }
    public String createDataMovie13(){
        String sql = "INSERT INTO \"phim\" VALUES('gt03','Transformers 3','Michael Bay','Shia LaBeouf, Josh Duhamel, John Turturro, Tyrese Gibson, Rosie Huntington Whiteley, Patrick Dempsey, Rich Hutchman, Frances McDormand, Kevin Dunn, John Malkovic','5','Bối cảnh phim diễn ra ở Trái đất với nội dung ngoài yếu tố hấp dẫn, hài hước thì phần 3 được bật mí sẽ cực kì bí ẩn. Phe Autobots gồm Bumblebee, Ratchet, Ironhide và Sideswipe do Optimus Prime lãnh đạo sẽ trở lại và đối đầu với phe Decepticons xấu xa, những kẻ quyết tâm trả thù cho thất bại của chúng. ','gt','kHRf01Gjosk');";
        return sql;
    }
    public String createDataMovie14(){
        String sql = "INSERT INTO \"phim\" VALUES('gt04','Transformers 4','Michael Bay','Mark Wahlberg, Nicola Peltz, Jack Reynor','5','TRANSFORMERS 4 được bắt đầu sau 4 năm về trận chiến ở Los Angeles trong phần trước Transformers: Dark of the Moon. Câu chuyện mở màn bởi những lời đồn đại về một thợ cơ khí và con gái của ông ta đã phát hiện ra một bí mật có thể khiến cả Autobots, Decepticons, và chính phủ Hoa Kỳ bị đe dọa.','gt','r8HPIH5JCak');";
        return sql;
    }
    public String createDataMovie15(){
        String sql = "INSERT INTO \"phim\" VALUES('gt05','Transformers 5','Michael Bay','Đang cập nhật','5','Với sự xuất hiện của kẻ thù mới, một trong những chủng tộc người ngoài hành tinh nhắm đến Trái Đất vì một mục đích là nguồn tài nguyên. Nhiệm vụ khó khăn hơn với nhóm Autobot là phải chiến đấu bảo vệ ngôi nhà thứ hai  của mình.','gt','GkKGM-dKNek');";
        return sql;
    }
    public String createDataMovie16(){
        String sql = "INSERT INTO \"phim\" VALUES('hd06','Cung sư huyền thoại','Haofeng Xu','Vu Thừa Huệ, Tống Dương, Lý Trình Viện','5','Thời thiếu niên Song Hỷ đã chính mắt nhìn thấy tỉ tỉ của mình gặp nạn, trong lòng Song Hỷ luôn bị ám ảnh bởi ký ức này. Bất ngờ Song Hỷ được thừa kế tiễn thuật cao siêu và trở thành một cao thủ trong võ lâm, với tên gọi Liễu Bạch Viên','hd','SC6njN8AG6g');";
        return sql;
    }
    public String createDataMovie17(){
        String sql = "INSERT INTO \"phim\" VALUES('hd07','Sniper:Special Ops 2016','Fred Olen Ray','Steven Seagal, Rob Van Dam, Tim Abell','5','Một lực lượng đặc biệt được chỉ huy bởi Trung Sĩ Jake Chandler, được cử đến đến một ngôi làng hẻo lánh ở Afghan để giải cứu một đại biểu quốc hội Hoa kì đang bị giữ bởi phiến quân Taliban. ','hd','1_Rmj_rtWlo');";
        return sql;
    }
    public String createDataMovie18(){
        String sql = "INSERT INTO \"phim\" VALUES('hd08','Winters War(2016)','Cedric Nicolas-Troyan','Chris Hemsworth, Jessica Chastain, Charlize Theron','5','Câu chuyện bắt đầu với Freya - em gái của Nữ hoàng ác Ravenna là Nữ hoàng băng giá, có năng lực đóng băng bất kỳ kẻ thù nào.','hd','POs2lEv7_6U');";
        return sql;
    }
    public String createDataMovie19(){
        String sql = "INSERT INTO \"phim\" VALUES('hd09','The Finest Hours','Craig Gillespie','Chris Pine, Casey Affleck, Ben Foster','5','Bộ phim mang chúng ta trở về ngày 18 tháng 2 năm 1952, một thảm họa thiên nhiên bất ngờ đã xảy ra trên vùng biển phía Đông nước Mỹ khiến tàu chở dầu lớn bị nứt làm đôi và đe dọa mạng sống của tất cả các thủy thủ.','hd','0jLXw5DqTbQ');";
        return sql;
    }
    public String createDataMovie20(){
//        String sql = "INSERT INTO \"phim\" VALUES('hd10','Dawn of Justice','Zack Snyder','Ben Affleck, Henry Cavill, Amy Adams','5','Ben Affleck, Henry Cavill, Amy Adams','hd','Zmu70sS4C34');";
//        return sql;
        String sql = "INSERT INTO \"phim\" VALUES('hd10','Dawn of Justice','Zack Snyder','Ben Affleck, Henry Cavill, Amy Adams','5','Nội dung bộ phim sẽ xoay quanh cuộc đối đầu có 1-0-2 của vị hiệp sĩ mạnh mẽ, đáng gờm nhất của thành phố Gotham với biểu tượng được tôn sùng nhất của thành phố Metropolis...','hd','0jLXw5DqTbQ');";
        return sql;
    }
    public String createDataMovie21(){
        String sql = "INSERT INTO \"phim\" VALUES('hh06','Justice League...','Sam Liu','Rosario Dawson, Christopher Gorham, Shemar Moore','5','Trong phim thì Justice League bị Trigon (bố của Raven) điều khiển và chỉ còn những người hùng trẻ tuổi của nhóm Teen Titans có thể ngăn chặn họ.','hh','HmLdaXERgZA');";
        return sql;
    }
    public String createDataMovie22(){
        String sql = "INSERT INTO \"phim\" VALUES('hh07','The Great Egg Scapade','Ricardo Curtis','Blake Anderson, Tyree Brown, David Cowgill','5','Ice Age The Great Egg-Scape là bản đặc biệt nhân dịp kỷ niệm lễ Phục Sinh từ đài FOX, bộ phim chia làm 3 phần. Phần đầu là câu chuyện tìm những quả trứng bị giấu bởi một tên thỏ cướp biển đáng ghét.','hh','37R0UXkisww');";
        return sql;
    }
    public String createDataMovie23(){
        String sql = "INSERT INTO \"phim\" VALUES('hh08','Capture the Flag','Enrique Gato','Dani Rovira, Michelle Jenner, Carme Calvell','5','Mike Goldwing, một cậu bé gan dạ, 12 tuổi, là cháu của cựu phi hành gia NASA - Frank. Ông Frank giờ đây đã về hưu và sống một mình sau khi ông bỏ lỡ cơ hội cùng phi hành gia Neil Armstrong và Buzz Aldrin thực hiện','hh','67YfSzkmDgw');";
        return sql;
    }
    public String createDataMovie24(){
        String sql = "INSERT INTO \"phim\" VALUES('hh09','The Road Chip(2016)','Walt Becker','Jason Lee, Jesica Ahlberg, Josh Green','5','Phim Sóc Siêu Quậy 4: Sóc Chuột Du Hí 2015 là câu chuyện tiếp nối về ban nhạc sóc chuột gồm 6 thành viên mang tên Chipmunks and Chipettes. ','hh','HzUNkgVRvZM');";
        return sql;
    }
    public String createDataMovie25(){
        String sql = "INSERT INTO \"phim\" VALUES('hh10','The Good Dinosaur','Peter Sohn','Jeffrey Wright, Frances McDormand, Maleah Nipay Padilla','5','Nửa cuối năm 2015 sẽ là khoảng thời gian đặc biệt với những khán giả yêu thích sự sáng tạo, bởi xưởng phim Pixar của Walt Disney Studios sẽ “chiêu đãi” hai bộ phim hoạt hình độc đáo','hh','hWemtpycSG0');";
        return sql;
    }
    public String createDataMovie26(){
        String sql = "INSERT INTO \"phim\" VALUES('gt06','Avarta','James Cameron','Zoe Saldana, Sam Worthington, Sigourney Weaver, Michelle Rodriguez','5','Avatar (biểu tượng đại diện) xoay quanh chuyến hành trình thám hiểm của Jake Sully (Sam Worthington), cựu sĩ quan thủy quân bị thương trong một cuộc chiến trên Trái Đất','gt','nbCY4SyH5dY');";
        return sql;
    }
    public String createDataMovie27(){
        String sql = "INSERT INTO \"phim\" VALUES('gt07','The First Avenger','Joe Johnston','Chris Evans, Hugo Weaving, Samuel L. Jackson, Richard Armitage, Tommy Lee Jones, Stanley Tucci, Hayley Atwell','5','Ban đầu, Captain America - Kẻ Báo Thù Đầu Tiên của hãng Marvel được tính quay ở Los Angeles, nhưng sau đó nhà sản xuất đã chuyển đến London, nơi là một phần trong bối cảnh của truyện','gt','hEBRkG9SCcs');";
        return sql;
    }
    public String createDataMovie28(){
        String sql = "INSERT INTO \"phim\" VALUES('gt08','Jonh Carter','Andrew Stantony','Taylor Kitsch, Lynn Collins, Willem Dafoe','5','Sao Hỏa, hay còn được các cư dân ở đó gọi là Barsoom, là nơi mà phần lớn câu chuyện này xảy ra. Đây từng là một hành tinh trù phú, một ngôi nhà của rất nhiều giống loài khác nhau','gt','s6vlvdsaGhU');";
        return sql;
    }
    public String createDataMovie29(){
        String sql = "INSERT INTO \"phim\" VALUES('gt09','Transformers 6','Michael Bay','Đang cập nhật','5','Với sự xuất hiện của kẻ thù mới, một trong những chủng tộc người ngoài hành tinh nhắm đến Trái Đất vì một mục đích là nguồn tài nguyên. Nhiệm vụ khó khăn hơn với nhóm Autobot là phải chiến đấu bảo vệ ngôi nhà thứ hai  của mình.','gt','GkKGM-dKNek');";
        return sql;
    }
    public String createDataMovie30(){
        String sql = "INSERT INTO \"phim\" VALUES('gt10','Harry Potter','David Yates','Daniel Radcliffe, Emma Watson, Rupert Grint','5','Phần 1 bắt đầu với việc Harry, Ron và Hermione thực thi nhiệm vụ hết sức nguy hiểm để theo dấu vết và phá hủy Trường Sinh Linh Giá - bí mật dẫn đến sự bất tử của Chúa tể Voldemort. ','gt','MxqsmsA8y5k');";
        return sql;
    }

}
