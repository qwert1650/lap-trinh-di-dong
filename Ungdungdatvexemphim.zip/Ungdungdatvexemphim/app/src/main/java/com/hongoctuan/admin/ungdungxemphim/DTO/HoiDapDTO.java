package com.hongoctuan.admin.ungdungxemphim.DTO;

/**
 * Created by admin on 6/9/2016.
 */
public class HoiDapDTO {
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTieude() {
        return tieude;
    }

    public void setTieude(String tieude) {
        this.tieude = tieude;
    }

    public String getNoidung() {
        return noidung;
    }

    public void setNoidung(String noidung) {
        this.noidung = noidung;
    }

    String id;
    String tieude;
    String noidung;
}
