package com.hongoctuan.admin.ungdungxemphim;

import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by admin on 4/16/2016.
 */
public class ViewHolder {
    TextView text;
    ImageView iv;
    Button bt;
}